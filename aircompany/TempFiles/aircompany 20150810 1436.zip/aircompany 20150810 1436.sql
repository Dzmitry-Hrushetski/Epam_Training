﻿--
-- Скрипт сгенерирован Devart dbForge Studio for MySQL, Версия 6.3.358.0
-- Домашняя страница продукта: http://www.devart.com/ru/dbforge/mysql/studio
-- Дата скрипта: 10.08.2015 14:38:02
-- Версия сервера: 5.6.25-log
-- Версия клиента: 4.1
--


-- 
-- Отключение внешних ключей
-- 
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;

-- 
-- Установить режим SQL (SQL mode)
-- 
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- 
-- Установка кодировки, с использованием которой клиент будет посылать запросы на сервер
--
SET NAMES 'utf8';

-- 
-- Установка базы данных по умолчанию
--
USE aircompany;

--
-- Описание для таблицы `position`
--
DROP TABLE IF EXISTS `position`;
CREATE TABLE `position` (
  id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  position_name VARCHAR(80) NOT NULL,
  PRIMARY KEY (id)
)
ENGINE = INNODB
AUTO_INCREMENT = 9
AVG_ROW_LENGTH = 2048
CHARACTER SET utf8
COLLATE utf8_unicode_ci;

--
-- Описание для таблицы airplane_type
--
DROP TABLE IF EXISTS airplane_type;
CREATE TABLE airplane_type (
  id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  model_name VARCHAR(70) NOT NULL,
  PRIMARY KEY (id)
)
ENGINE = INNODB
AUTO_INCREMENT = 8
AVG_ROW_LENGTH = 2340
CHARACTER SET utf8
COLLATE utf8_unicode_ci
PACK_KEYS = 1;

--
-- Описание для таблицы city
--
DROP TABLE IF EXISTS city;
CREATE TABLE city (
  id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  city_name VARCHAR(70) NOT NULL,
  PRIMARY KEY (id)
)
ENGINE = INNODB
AUTO_INCREMENT = 8
AVG_ROW_LENGTH = 2340
CHARACTER SET utf8
COLLATE utf8_unicode_ci;

--
-- Описание для таблицы person
--
DROP TABLE IF EXISTS person;
CREATE TABLE person (
  id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  first_name VARCHAR(50) NOT NULL,
  last_name VARCHAR(50) NOT NULL,
  addres VARCHAR(80) NOT NULL,
  phone VARCHAR(50) DEFAULT NULL,
  user_name VARCHAR(50) DEFAULT NULL,
  password VARCHAR(25) DEFAULT NULL,
  disable TINYINT(4) DEFAULT 0,
  PRIMARY KEY (id),
  UNIQUE INDEX user_name_unique_index (user_name)
)
ENGINE = INNODB
AUTO_INCREMENT = 2
AVG_ROW_LENGTH = 16384
CHARACTER SET utf8
COLLATE utf8_unicode_ci;

--
-- Описание для таблицы airplane
--
DROP TABLE IF EXISTS airplane;
CREATE TABLE airplane (
  id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  airplane_type_id INT(11) UNSIGNED NOT NULL DEFAULT 0,
  board_number VARCHAR(50) NOT NULL,
  PRIMARY KEY (id),
  CONSTRAINT ref_airplane_airplane_type FOREIGN KEY (airplane_type_id)
    REFERENCES airplane_type(id) ON DELETE NO ACTION ON UPDATE NO ACTION
)
ENGINE = INNODB
AUTO_INCREMENT = 18
AVG_ROW_LENGTH = 963
CHARACTER SET utf8
COLLATE utf8_unicode_ci;

--
-- Описание для таблицы airport
--
DROP TABLE IF EXISTS airport;
CREATE TABLE airport (
  id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  city_id INT(11) UNSIGNED NOT NULL DEFAULT 0,
  airport_name VARCHAR(70) NOT NULL,
  iata_code VARCHAR(10) DEFAULT NULL,
  icao_code VARCHAR(10) DEFAULT NULL,
  PRIMARY KEY (id),
  CONSTRAINT ref_airport_city FOREIGN KEY (city_id)
    REFERENCES city(id) ON DELETE NO ACTION ON UPDATE NO ACTION
)
ENGINE = INNODB
AUTO_INCREMENT = 10
AVG_ROW_LENGTH = 1820
CHARACTER SET utf8
COLLATE utf8_unicode_ci;

--
-- Описание для таблицы composition_crew
--
DROP TABLE IF EXISTS composition_crew;
CREATE TABLE composition_crew (
  id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  airplane_type_id INT(11) UNSIGNED NOT NULL DEFAULT 0,
  position_id INT(11) UNSIGNED NOT NULL DEFAULT 0,
  quantity SMALLINT(6) UNSIGNED DEFAULT NULL,
  PRIMARY KEY (id),
  CONSTRAINT ref_composition_crew_airplane_type FOREIGN KEY (airplane_type_id)
    REFERENCES airplane_type(id) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT ref_composition_crew_position FOREIGN KEY (position_id)
    REFERENCES `position`(id) ON DELETE NO ACTION ON UPDATE NO ACTION
)
ENGINE = INNODB
AUTO_INCREMENT = 10
AVG_ROW_LENGTH = 1820
CHARACTER SET utf8
COLLATE utf8_unicode_ci;

--
-- Описание для таблицы employee
--
DROP TABLE IF EXISTS employee;
CREATE TABLE employee (
  id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  person_id INT(11) UNSIGNED NOT NULL DEFAULT 0,
  position_id INT(11) UNSIGNED NOT NULL DEFAULT 0,
  start_date DATE NOT NULL,
  disable TINYINT(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  CONSTRAINT ref_employee_person FOREIGN KEY (person_id)
    REFERENCES person(id) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT ref_employee_position FOREIGN KEY (position_id)
    REFERENCES `position`(id) ON DELETE NO ACTION ON UPDATE NO ACTION
)
ENGINE = INNODB
AUTO_INCREMENT = 2
AVG_ROW_LENGTH = 16384
CHARACTER SET utf8
COLLATE utf8_unicode_ci;

--
-- Описание для таблицы route
--
DROP TABLE IF EXISTS route;
CREATE TABLE route (
  id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  departure_airport_id INT(11) UNSIGNED NOT NULL DEFAULT 0,
  arrival_airport_id INT(11) UNSIGNED NOT NULL DEFAULT 0,
  airplane_id INT(11) UNSIGNED NOT NULL DEFAULT 0,
  departure_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  arrival_time TIMESTAMP NOT NULL DEFAULT '0000-00-00 00:00:00',
  route_number VARCHAR(25) DEFAULT NULL,
  disable TINYINT(4) DEFAULT 0,
  PRIMARY KEY (id),
  CONSTRAINT ref_route_airplane FOREIGN KEY (airplane_id)
    REFERENCES airplane(id) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT ref_route_arrival_airport FOREIGN KEY (arrival_airport_id)
    REFERENCES airport(id) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT ref_route_departure_airport FOREIGN KEY (departure_airport_id)
    REFERENCES airport(id) ON DELETE NO ACTION ON UPDATE NO ACTION
)
ENGINE = INNODB
AUTO_INCREMENT = 1
CHARACTER SET utf8
COLLATE utf8_unicode_ci;

--
-- Описание для таблицы crew
--
DROP TABLE IF EXISTS crew;
CREATE TABLE crew (
  id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  route_id INT(11) UNSIGNED NOT NULL DEFAULT 0,
  employee_id INT(11) UNSIGNED NOT NULL DEFAULT 0,
  disable TINYINT(4) DEFAULT 0,
  PRIMARY KEY (id),
  UNIQUE INDEX employee_by_route_unique_index (route_id, employee_id),
  CONSTRAINT ref_crew_employee FOREIGN KEY (employee_id)
    REFERENCES employee(id) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT ref_crew_route FOREIGN KEY (route_id)
    REFERENCES route(id) ON DELETE NO ACTION ON UPDATE NO ACTION
)
ENGINE = INNODB
AUTO_INCREMENT = 1
CHARACTER SET utf8
COLLATE utf8_unicode_ci;

-- 
-- Вывод данных для таблицы `position`
--
INSERT INTO `position` VALUES
(1, 'Директор'),
(2, 'Администратор'),
(3, 'Диспетчер'),
(4, 'Командир воздушного судна'),
(5, 'Второй пилот'),
(6, 'Бортинженер'),
(7, 'Штурман'),
(8, 'Бортпроводник');

-- 
-- Вывод данных для таблицы airplane_type
--
INSERT INTO airplane_type VALUES
(1, ' Ту-154 М'),
(2, 'Boeing 737-800'),
(3, 'Boeing 737-500'),
(4, 'Boeing 737-300'),
(5, 'CRJ-200 LR'),
(6, 'Embraer 195'),
(7, ' Embraer 175');

-- 
-- Вывод данных для таблицы city
--
INSERT INTO city VALUES
(1, 'Минск'),
(2, 'Гомель'),
(3, 'Санкт Петербург'),
(4, 'Москва'),
(5, 'Бургас'),
(6, 'Варшава'),
(7, 'Киев');

-- 
-- Вывод данных для таблицы person
--
INSERT INTO person VALUES
(1, 'Игорь', 'Смирнов', 'Минск ул. Городецкая д.20 к.47', '+375291230000', 'director@director.com', 'director', 0);

-- 
-- Вывод данных для таблицы airplane
--
INSERT INTO airplane VALUES
(1, 1, 'RA-85069'),
(2, 1, 'RA-85123'),
(3, 1, 'RA-85695'),
(4, 2, 'EW-790PA'),
(5, 2, 'EW-437PA'),
(6, 3, 'EW-250PA'),
(7, 3, 'EW-251PA'),
(8, 3, 'EW-252PA'),
(9, 4, 'EW-254PA'),
(10, 4, 'EW-283PA'),
(11, 4, 'EW-282PA'),
(12, 5, 'EW-277PJ'),
(13, 5, 'EW-276PJ'),
(14, 6, 'EW-399PO'),
(15, 6, 'EW-400PO'),
(16, 7, 'EW-340PO'),
(17, 7, 'EW-341PO');

-- 
-- Вывод данных для таблицы airport
--
INSERT INTO airport VALUES
(1, 1, 'Национальный аэропорт Минск', 'MSQ', 'UMMS'),
(2, 2, 'Аэропорт Гомель', 'GME', 'UMGG'),
(3, 3, 'Пулково', 'LED', 'ULLI'),
(4, 4, 'Внуково', 'VKO', 'UUWW'),
(5, 4, 'Домодедово', 'DME', 'UUDD'),
(6, 4, 'Шереметьео', 'SVO', 'UUEE'),
(7, 5, 'Бургас', 'BOJ', 'LBBG'),
(8, 6, 'Фредерик Шопен', 'WAW', 'EPWA'),
(9, 7, 'Борисполь', 'KBP', 'UKBB');

-- 
-- Вывод данных для таблицы composition_crew
--
INSERT INTO composition_crew VALUES
(1, 1, 4, 1),
(2, 1, 5, 1),
(3, 1, 6, 1),
(4, 1, 8, 4),
(5, 2, 4, 1),
(6, 2, 5, 1),
(7, 2, 6, 1),
(8, 2, 7, 1),
(9, 2, 8, 7);

-- 
-- Вывод данных для таблицы employee
--
INSERT INTO employee VALUES
(1, 1, 1, '2014-08-01', 0);

-- 
-- Вывод данных для таблицы route
--

-- Таблица aircompany.route не содержит данных

-- 
-- Вывод данных для таблицы crew
--

-- Таблица aircompany.crew не содержит данных

-- 
-- Восстановить предыдущий режим SQL (SQL mode)
-- 
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;

-- 
-- Включение внешних ключей
-- 
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;